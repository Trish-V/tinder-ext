declare var getChrome: any;
export const environment = {
  production: true 
};
